ODK documentation is available online at http://devs.ouya.tv/developers/docs
